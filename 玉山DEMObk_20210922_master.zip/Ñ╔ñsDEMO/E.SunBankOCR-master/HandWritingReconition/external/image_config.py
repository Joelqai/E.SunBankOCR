image_height = None
image_width = None
channels = None