### 使用方式
## 1.先把蒐集來的資料分成數個class的資料夾,然後使用HandWritingDataset的pipeline.py進行資料前處理並切割train, valid, test資料集
# 程式功能說明 : 把蒐集到的圖庫資料，拆成3組TRAINNING用的DATA(train, valid, test)，各自存放專屬的資料夾。
# [備註] 可自行先做資料前處理，把要TRAIN的資料用料夾用class名稱命名區開，預先分門別類處理好。

##2.修改HandWritingReconition/config/experiments/exp_config_classifier.yaml內部的 TRAIN_DIR,VALID_DIR,TEST_DIR,也可以調整backbone
# 程式功能說明 : 
# 此為Model的參數設定檔，可以直接用記事本打開做內容設定修改。
# 此設定檔是用來要做模型參數訓練跟調整用途的設置檔案

## 3.執行sample.py進行訓練,會根據給入的yaml進行資料匯入,模型建構,並開始訓練模型
# 程式功能說明 : 
# sample.py，可以修改部分程式碼，調整TRAINNING的設定檔(exp_config_classifier.yaml)。
# 如果沒有對 cfg = load_config(config_file)，重新設定/給予新的變數值數值。Default會直接用 exp_config_classifier.yaml檔案載入時的設定值(競賽時使用的參數設定)，當作TRAINNING條件。